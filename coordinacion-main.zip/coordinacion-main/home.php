<?php
session_start();

$id_user = $_SESSION['id_user'];

if (!$id_user){
    header('Location: index.php')
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Hola</title>
    <?php include ('scripts.php'); ?>
</head>

<body>
    <div id="menu" class="col-sm-10 mt-4 mx-auto" style="display: flex; justify-content: space-between">
        <input class="form-control form-control-lg" type="text" placeholder="Aprendiz" aria-label=".form-control-lg example">
        <button type="button" class="btn btn-outline-info">Info</button>
        <button type="button" class="btn btn-outline-info">Info</button>
    </div>
    
</body>
</html>

