function mostrar_datos_aprendiz(aprendiz) {
    var table = $("<table>");

    var thead = $("<thead>");
    var trHead = $("<tr>");
    trHead.append($("<th>").text("Nombre"));
    trHead.append($("<th>").text("Documento"));
    trHead.append($("<th>").text("Email"));
    thead.append(trHead);
    table.append(thead);

    var tr = $("<tr>");
    tr.append($("<td>").text(aprendiz.nombres + aprendiz.apellidos));
    tr.append($("<td>").text(aprendiz.documento));
    tr.append($("<td>").text(aprendiz.email));
    table.append(tr);

    $("#resultado").html(table);
}

function mostrar_datos_historial(historial) {
    
}

$(document).ready(function() {
    $("#btnBuscar").click(function(){
        var documento = $("#documento").val();
        $.ajax({
            url: "http://localhost/coordinacion-main/busqueda.php",
            type: "POST",
            dataType: "json",
            data: {
                "documento":documento
            },
            success: function(data) {
                if (data.estado=="OK") {
                    mostrar_datos_aprendiz(data.resultado.aprendiz);
                    mostrar_datos_historial(data.resultado.historial);
                } else {
                    $("#resultado").text(data.msg);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(errorThrown);
            }
        });
    });
});